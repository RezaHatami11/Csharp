﻿
using System;

class Program
{
    static void Main()
    {
        Console.Write("Please enter the radius of the circle: ");

        // دریافت مقدار ورودی از کاربر
        string input = Console.ReadLine();

        // تبدیل مقدار ورودی به عدد اعشاری
        if (double.TryParse(input, out double radius) && radius > 0)
        {
            double perimeter = 2 * Math.PI * radius; // محیط دایره
            double area = Math.PI * Math.Pow(radius, 2); // مساحت دایره

            Console.WriteLine($"perimeter of circle : {perimeter:F2}");
            Console.WriteLine($"Area of circle: {area:F2}");
        }
        else
        {
            Console.WriteLine("lotfan meqdar motabar vared konid.");
        }

        Console.ReadKey(); // نگه داشتن صفحه کنسول
    }
}