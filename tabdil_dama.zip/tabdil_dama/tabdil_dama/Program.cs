﻿using System;

namespace TemperatureConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            // دریافت دمای سانتیگراد از کاربر
            Console.Write("Damaye Celsius vared konid: ");
            double celsius = double.Parse(Console.ReadLine());

            // تبدیل سانتیگراد به فارنهایت
            double fahrenheit = (celsius * 9 / 5) + 32;

            // نمایش نتیجه با یک رقم اعشار
            Console.WriteLine($"Damye Farenheit: {fahrenheit:F1}");
        }
    }
}